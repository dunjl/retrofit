package com.example.qiujinlun.template.model.Event;

public class TitleEvent {
    private String message;
    public TitleEvent(String Msg){
        this.message=Msg;
    }

    public String getMessage() {
        return message;
    }
}
