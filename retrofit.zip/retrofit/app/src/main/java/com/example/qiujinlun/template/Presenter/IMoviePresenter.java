package com.example.qiujinlun.template.Presenter;

public interface IMoviePresenter {
    public void getMovieMsg(int start,int count);
}
